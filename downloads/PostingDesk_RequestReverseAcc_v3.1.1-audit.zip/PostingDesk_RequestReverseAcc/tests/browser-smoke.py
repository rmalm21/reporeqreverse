from pathlib import Path
import argparse
import shutil
from playwright.sync_api import sync_playwright, expect

parser = argparse.ArgumentParser(description='Smoke browser Posting Desk dalam mode demo.')
parser.add_argument('--url', default='http://127.0.0.1:8080')
parser.add_argument('--chromium', default=shutil.which('chromium'))
parser.add_argument('--screenshots', type=Path)
args = parser.parse_args()
URL = args.url.rstrip('/') + '/?demo=1&room=cancel&entity=AIO'
if args.screenshots:
    args.screenshots.mkdir(parents=True, exist_ok=True)

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=args.chromium, headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'])
    for name, viewport in [('desktop', {'width': 1440, 'height': 1000}), ('mobile', {'width': 390, 'height': 844})]:
        context = browser.new_context(viewport=viewport)
        page = context.new_page()
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.route('https://**/*', lambda route: route.abort())
        page.goto(URL)
        expect(page.locator('#page-title')).to_have_text('Cancel Park')
        expect(page.locator('#list-summary')).to_contain_text('2 dokumen')
        expect(page.locator('#bulk-delete')).to_be_visible()
        expect(page.locator('#bulk-delete')).to_be_disabled()
        first = page.locator('#request-rows [data-detail]').first.get_attribute('data-detail')
        page.locator(f'[data-detail="{first}"]').click()
        expect(page.locator('#detail-delete')).to_be_enabled()
        page.locator('#detail-delete').click()
        expect(page.locator('#confirm-title')).to_have_text('Hapus 1 dokumen?')
        page.locator('#confirm-action').click()
        expect(page.locator('#list-summary')).to_contain_text('1 dokumen')
        page.locator('[data-view="trash"]').click()
        page.locator(f'[data-detail="{first}"]').click()
        expect(page.locator('#detail-action')).to_have_text('Pulihkan dari Sampah')
        page.locator('#detail-action').click()
        page.locator('#confirm-action').click()
        expect(page.locator('#list-summary')).to_contain_text('0 dokumen')
        page.locator('[data-view="pending"]').click()
        expect(page.locator('#list-summary')).to_contain_text('2 dokumen')
        print(f'{name}: single Cancel Park delete and restore passed')

        page.locator('[data-view="done"]').click()
        page.evaluate('''() => {
          document.getElementById('date-preset').value = 'custom';
          document.getElementById('date-from').value = '2026-10-20';
          document.getElementById('date-to').value = '2026-10-01';
          document.getElementById('date-preset').dispatchEvent(new Event('change', {bubbles: true}));
        }''')
        expect(page.locator('#filter-error')).to_be_visible()
        page.locator('[data-room="reverse"]').click()
        page.locator('[data-room="cancel"]').click()
        expect(page.locator('#period-filter')).to_be_hidden()
        page.locator('#select-all').check()
        expect(page.locator('#bulk-delete')).to_be_enabled()
        page.locator('#bulk-delete').click()
        page.locator('#confirm-action').click()
        expect(page.locator('#list-summary')).to_contain_text('0 dokumen')
        page.locator('[data-view="trash"]').click()
        expect(page.locator('#list-summary')).to_contain_text('2 dokumen')
        page.locator('#select-all').check()
        page.locator('#bulk-undelete').click()
        page.locator('#confirm-action').click()
        expect(page.locator('#list-summary')).to_contain_text('0 dokumen')
        page.locator('[data-view="pending"]').click()
        expect(page.locator('#list-summary')).to_contain_text('2 dokumen')
        print(f'{name}: invalid hidden date filter, bulk delete and restore passed')
        assert not errors, errors
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), 'Horizontal page overflow'
        if args.screenshots:
            page.screenshot(path=str(args.screenshots / f'posting-desk-{name}.png'), full_page=True)
        context.close()
    browser.close()
print('Browser smoke checks passed; no JavaScript page errors.')
