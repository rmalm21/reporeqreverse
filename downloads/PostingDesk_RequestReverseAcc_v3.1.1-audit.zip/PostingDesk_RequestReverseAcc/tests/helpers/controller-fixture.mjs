import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRecord, matchesScope, recordId, todayJakarta, transitionPatch } from '../../public/domain.js';

export async function controllerFixture({ role = 'poster', cached = false, preferences = '{}', findDocuments } = {}) {
  const actor = { uid: 'test-user', displayName: 'Test User', role };
  const today = todayJakarta();
  let rows = ['reverse', 'cancel'].flatMap(operation => ['AIO', 'ODI'].map(entity => {
    const row = createRecord({ operation, entity, fiscalYear: today.slice(0, 4), requestDate: today, note: '' }, '5000000099', actor, 1000);
    return { ...row, id: recordId(row) };
  }));
  let receive, activeScope, authChanged;
  let metadata = { cached, pendingWrites: false, mayHaveMore: false };
  const mutations = [];
  const emit = () => receive?.(rows.filter(row => matchesScope(row, activeScope)), metadata);
  const repository = {
    subscribe(scope, next) { activeScope = scope; receive = next; emit(); return () => { receive = null; }; },
    async getOpenCounts() { return { reverse: { total: 2, AIO: 1, ODI: 1 }, cancel: { total: 2, AIO: 1, ODI: 1 } }; },
    async mutate(ids, action, scope, knownRows) {
      mutations.push({ ids, action, scope, knownRows });
      let changed = 0;
      rows = rows.map(row => {
        if (!ids.includes(row.id) || !matchesScope(row, scope)) return row;
        const patch = transitionPatch(row, action, actor, row.updatedAt + 1000);
        if (!patch) return row;
        changed++; return { ...row, ...patch };
      });
      emit(); return { changed, skipped: ids.length - changed };
    },
    findDocuments: findDocuments || (async () => ({ rows: [], missing: [], truncated: false }))
  };
  const ids = {};
  class Element {
    constructor(id = '', tag = 'div') {
      Object.assign(this, { id, tag, value: '', textContent: '', innerHTML: '', hidden: false, disabled: false, checked: false, open: false, dataset: {}, handlers: {}, attributes: {}, classes: new Set() });
      this.classList = { add: v => this.classes.add(v), remove: v => this.classes.delete(v), toggle: (v, on) => on ? this.classes.add(v) : this.classes.delete(v) };
    }
    setAttribute(name, value) { this.attributes[name] = value; }
    addEventListener(name, handler) { this.handlers[name] = handler; }
    showModal() { this.open = true; }
    close() { this.open = false; }
    focus() {}
    select() {}
    scrollIntoView() {}
    reset() { for (const [id, e] of Object.entries(ids)) if (id.startsWith('form-')) e.value = ''; }
    closest(selector) { const match = selector.match(/^\[data-([^\]]+)\]$/); return match && Object.hasOwn(this.dataset, match[1]) ? this : null; }
  }
  const html = fs.readFileSync(new URL('../../public/index.html', import.meta.url), 'utf8');
  for (const match of html.matchAll(/<([a-z]+)[^>]*id="([^"]+)"[^>]*>/g)) ids[match[2]] = new Element(match[2], match[1]);
  const controls = {};
  for (const kind of ['room', 'entity', 'view', 'audience', 'density']) {
    controls[kind] = [...html.matchAll(new RegExp(`data-${kind}="([^"]+)"`, 'g'))].map(match => {
      const node = new Element(); node.dataset[kind] = match[1]; return node;
    });
  }
  const handlers = {}, windowHandlers = {};
  const globals = {
    document: {
      title: '', getElementById: id => ids[id], querySelector: () => null,
      querySelectorAll(selector) {
        const match = selector.match(/^\[data-(room|entity|view|audience|density)\]$/);
        if (match) return controls[match[1]];
        if (selector === 'dialog' || selector === 'dialog[open]') return Object.values(ids).filter(e => e.tag === 'dialog' && (selector === 'dialog' || e.open));
        return [];
      },
      addEventListener: (type, fn) => { handlers[type] = fn; }
    },
    localStorage: { getItem: key => key === 'posting-desk-ui-v1' ? preferences : null, setItem() {} },
    location: { search: '?room=cancel', href: 'http://localhost/?room=cancel', origin: 'http://localhost', protocol: 'http:' },
    history: { replaceState() {} },
    window: { addEventListener: (type, fn) => { windowHandlers[type] = fn; } },
    navigator: { onLine: true, clipboard: { async writeText() {} } },
    setTimeout: () => 0, clearTimeout() {},
    __testConnectFirebase: async (_, changed) => {
      authChanged = changed;
      changed({ actor, repository });
      return { logout: async () => changed(null), destroy() {} };
    }
  };
  const saved = Object.fromEntries(Object.keys(globals).map(key => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  for (const [key, value] of Object.entries(globals)) Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'posting-desk-controller-'));
  const cleanup = () => {
    fs.rmSync(temp, { recursive: true, force: true });
    for (const [key, descriptor] of Object.entries(saved)) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else delete globalThis[key];
    }
  };
  try {
    // Only replace the Firebase CDN connection; execute the actual controller and its dependencies.
    const fakeFirebase = 'data:text/javascript,' + encodeURIComponent('export async function connectFirebase(config, next) { return globalThis.__testConnectFirebase(config, next); }');
    const source = fs.readFileSync(new URL('../../public/app.js', import.meta.url), 'utf8')
      .replace(/(from\s+|import\s*\()(['"])(\.\/[^'"]+)\2/g, (_, prefix, quote, specifier) => {
        const url = specifier === './firebase-store.js' ? fakeFirebase : new URL(specifier, new URL('../../public/app.js', import.meta.url)).href;
        return prefix + quote + url + quote;
      });
    const controller = path.join(temp, 'controller.mjs');
    fs.writeFileSync(controller, source);
    await import(pathToFileURL(controller).href);
    for (let i = 0; i < 30 && !authChanged; i++) await new Promise(resolve => setImmediate(resolve));
    if (!authChanged) throw new Error(ids['gate-message'].textContent || 'Controller failed to start');
  } catch (error) { cleanup(); throw error; }
  return {
    ids, actor, mutations, cleanup,
    click(kind, value) { const target = controls[kind].find(e => e.dataset[kind] === value); handlers.click({ target }); },
    detail(id = rows.find(row => matchesScope(row, activeScope))?.id) { const target = new Element(); target.dataset.detail = id; handlers.click({ target }); },
    sync(next) { metadata = { ...metadata, ...next }; emit(); },
    update(id, patch) { rows = rows.map(row => row.id === id ? { ...row, ...patch } : row); emit(); },
    signOut() { authChanged(null); },
    online(value) { globals.navigator.onLine = value; windowHandlers[value ? 'online' : 'offline']?.(); },
    rows: () => rows
  };
}
