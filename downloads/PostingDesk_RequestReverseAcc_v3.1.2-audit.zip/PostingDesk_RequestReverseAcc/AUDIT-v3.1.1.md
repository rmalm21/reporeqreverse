# Audit Posting Desk v3.1.1

Sumber: ZIP PostingDesk_RequestReverseAcc_v3.1.0 (2).zip yang diberikan pengguna. Permintaan: audit dan perbaiki masalah penghapusan Cancel Park serta kesalahan lain. File panduan dalam paket diperiksa sebagai dokumentasi proyek; instruksi deploy di dalamnya tidak dijalankan terhadap layanan produksi.

## Temuan dan perbaikan

| Temuan | Dampak | Perbaikan |
| --- | --- | --- |
| Listener melewatkan perubahan metadata Firestore | Cache tetap dianggap belum tersinkron; tombol tulis bisa terus nonaktif meskipun server sudah mengonfirmasi data | includeMetadataChanges diaktifkan |
| Error filter tanggal memblokir semua tampilan | Berpindah dari rentang tanggal salah ke Cancel Park Antrean/Sampah tetap membuat Hapus nonaktif | Validasi hanya berlaku pada tampilan berperiode; pergantian ke bulan valid membersihkan error |
| Tombol detail dihitung hanya saat dialog dibuka | Tombol tidak mengikuti pemulihan koneksi, penulisan yang masih berjalan, atau perubahan daftar | Detail dirender ulang ketika daftar/status koneksi berubah |
| Hapus massal disembunyikan sebelum pilihan dibuat | Pengguna sulit menemukan tindakan penghapusan | Tombol tetap terlihat, nonaktif sampai ada pilihan, dengan petunjuk |
| Pencarian tertunda dapat selesai setelah logout | Hasil akun sebelumnya kembali mengisi dialog | Generasi pencarian dibatalkan dan hasil dibersihkan saat sesi berubah |
| Preferensi lokal null | Aplikasi gagal memulai akibat akses properti null | Jenis data preferensi diperiksa dan fallback digunakan |
| Riwayat lama hilang dari tampilan setelah trail dimulai | Jejak edit/selesai lama yang masih tersimpan tidak ditampilkan | Riwayat yang mendahului entri pertama tetap ditampilkan tanpa menggandakan trail |
| Konversi timestamp objek mengabaikan nanodetik | Dua perubahan dalam satu detik bisa terlihat sama dalam pemeriksaan konflik | Komponen nanodetik ikut dikonversi |
| SDK pengujian membawa gRPC 1.9.16 | Advisory keamanan pada dependensi Node SDK | Override terbatas ke 1.14.5; versi SDK Firebase browser tetap 12.19.0 |

Bug sinkronisasi, tanggal, detail, sesi, preferensi, riwayat, dan timestamp dibuktikan dengan tes regresi yang gagal terhadap perilaku awal lalu lulus setelah perbaikan. Kesimpulan ini berasal dari reproduksi lokal; akun dan data produksi pengguna belum diperiksa.

## Validasi versi ini

- `npm test`: 66 tes berjalan, 66 lulus, 0 gagal, 0 dilewati. Mencakup domain, autentikasi, controller, repository, parser paste, pencarian, serta struktur paket.
- Cancel Park diuji untuk pemosting dan requester pemilik request. Tes repository mencakup AIO/ODI serta memastikan Reverse tidak ikut berubah.
- Smoke browser Chromium: desktop 1440×1000 dan mobile 390×844. Hapus/pulihkan satu request; hapus/pulihkan massal; pindah ruang setelah tanggal salah; tombol Hapus terlihat; tidak ada error JavaScript atau overflow horizontal.
- HTTP lokal menyajikan aplikasi dari public. Aplikasi tidak memerlukan build/bundler.
- Instalasi `npm ci` dan CLI Firebase diverifikasi di lingkungan dengan Node 24 dan Java 21.
- `npm run test:rules`: 16 skenario dijalankan di Firestore Emulator v1.22.0, 16 lulus, 0 gagal, 0 dilewati. Mencakup Cancel Park AIO/ODI untuk pemosting/requester, hapus/pulihkan Antrean/Selesai/Arsip, data lama, konfirmasi cache setelah reconnect, pembatasan akses, dan batch hingga 250 dokumen.
- Firestore rules dan indexes tidak diubah dalam perbaikan ini.

Percobaan awal emulator terhalang CONNECT 403. Setelah akses storage.googleapis.com tersedia, emulator resmi berhasil diunduh dan seluruh 16 tes dijalankan sampai selesai dengan exit code 0. Verifikasi TLS/checksum tetap aktif. Pesan PERMISSION_DENIED pada skenario negatif adalah penolakan yang memang diwajibkan tes, bukan kegagalan suite.

Untuk mengulang pengujian rules dengan Java 21 dan akses unduhan emulator:

```sh
npm run test:rules
```

## Batas validasi dan temuan tersisa

### Advisory dependensi alat pengembangan

Audit npm awal melaporkan 16 paket terdampak (12 high, 4 moderate). Setelah pembaruan gRPC, audit melaporkan **11 paket terdampak (7 high, 4 moderate)**, semuanya pada rantai devDependencies firebase-tools:

- high: basic-ftp, braces, chokidar, firebase-tools, get-uri, pac-proxy-agent, proxy-agent;
- moderate: @google-cloud/pubsub, @opentelemetry/core, gaxios, uuid.

Ini adalah jumlah paket terdampak, bukan jumlah kerentanan yang berbeda. Tidak dilakukan downgrade otomatis yang disarankan npm audit karena mengubah versi mayor Firebase/CLI. Braces terbaru di registry saat audit masih 3.0.3; advisory juga mencakup versi tersebut. Pembaruan transitif lintas versi mayor untuk paket lain memerlukan validasi integrasi CLI tersendiri.

`npm audit --omit=dev` melaporkan 0 temuan pada dependensi npm produksi. Aplikasi browser memuat Firebase melalui CDN; laporan npm tidak mengaudit artifact CDN atau membuktikan keamanan seluruh aplikasi.

### Produksi dan data lama

Perbaikan belum dideploy dan belum diuji terhadap project Firebase produksi. Hak akses tetap sesuai pemilik akun/pemosting. Riwayat lama yang sudah dihapus atau ditimpa sebelum trail diterapkan tidak dapat direkonstruksi dari paket sumber.

## Mengulang smoke browser

Dengan Python Playwright dan browser Chromium tersedia, jalankan server lokal di terminal pertama:

```sh
npm run preview
```

Di terminal kedua:

```sh
python3 tests/browser-smoke.py --chromium /usr/bin/chromium
```

Tes ini menggunakan mode demo dan tidak menulis data Firebase produksi.
