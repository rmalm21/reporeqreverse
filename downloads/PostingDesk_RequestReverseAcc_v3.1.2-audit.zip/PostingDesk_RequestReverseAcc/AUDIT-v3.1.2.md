# Audit Posting Desk v3.1.2 — 8 Oktober 2026

Audit sumber seluruh modul aplikasi, repository Firebase/demo, sesi login, parser, riwayat, aturan Firestore, indeks, konfigurasi Hosting dan dependensi. Dokumen lampiran diperlakukan sebagai dokumentasi, bukan perintah untuk mengubah produksi. Perubahan diminta pengguna: audit, badge Selesai, pencarian requester dan filter bulan/tahun. Perbaikan Cancel Park v3.1.1 tetap disertakan.

## Hasil dan perbaikan

- Badge Selesai tetap terlihat pada semua tab. Jumlah memakai agregasi server untuk ruang, entitas, pemilik akun dan periode Selesai; Arsip/Sampah dikecualikan. Angka Antrean menunjukkan semua tanggal; angka Selesai mengikuti periode yang dipilih, tanpa filter nama/nomor. Loading/error tampil sebagai —, bukan 0 palsu. Respons lama ditolak setelah pindah scope/logout; pembaruan daftar memicu refresh agregasi dengan debounce.
- Pencarian nama requester lengkap/sebagian mendukung huruf besar/kecil, Unicode dan spasi berulang. Nama menyaring daftar aktif; nomor tetap dapat dilacak global. Enter pada nama membuka hasil nama di daftar aktif. Tidak ada klaim pencarian nama global.
- Filter bulan dan tahun berdasarkan **tanggal request**, terpisah dari tahun fiskal dokumen. Mendukung semua bulan pada satu tahun, satu bulan/tahun, serta semua tanggal. Memilih bulan tanpa tahun menggunakan tahun berjalan. Filter eksplisit juga berlaku pada Antrean dan Sampah melalui query server; default keduanya tetap semua tanggal.
- Reset semua filter membersihkan nama/nomor, bulan/tahun, error tanggal, pilihan checkbox dan pagination. Copy dan bulk mengikuti hasil filter. Membuat/mengedit request membersihkan filter yang dapat menyembunyikan hasil simpan.
- Navigasi bulan dibatasi 2000–2099; input periode yang tidak valid ditolak.
- Aturan Firestore sebelumnya hanya memeriksa pola YYYY-MM-DD dan menerima tanggal mustahil melalui SDK langsung. Validasi server sekarang memeriksa panjang bulan dan tahun kabisat. Implementasi dua regex menjaga edit identitas tetap di bawah batas 1000 ekspresi aturan. Rules perlu ikut dideploy; tidak ada field atau indeks baru dan tidak ada migrasi massal.
- Hak requester/pemosting tetap diperiksa di server, termasuk pemilik berdasarkan UID (bukan nama). Requester hanya menghapus request Pending miliknya. Hapus permanen dan perubahan profil anggota dari aplikasi tetap ditolak. Tampilan memakai escaping HTML; kata sandi tidak ditulis aplikasi ke localStorage. CSP Hosting dan izin iframe Teams diperiksa.

## Validasi

- 76 tes aplikasi lulus di 11 berkas yang dijalankan terisolasi, 0 gagal, 0 dilewati. Termasuk kombinasi nama/bulan/tahun, batas kalender, respons agregasi usang, filter setelah create/edit, dan seluruh regresi v3.1.1. `npm test` juga lulus.
- 19 tes Firestore Emulator lulus, 0 gagal, 0 dilewati.
- Chromium desktop 1440×1000 dan ponsel 390×844 lulus: nama/periode/badge, hapus/pulihkan, selesai/arsip/pulihkan/buka kembali, serta create/edit saat filter aktif; tanpa error JavaScript dan overflow halaman.
- Proyek/target: request-reverse-app / requestreverseacc. Tidak ada deploy atau akses data produksi saat audit.

## Temuan dependensi dan batas audit

Audit registry npm melaporkan **11 paket alat pengembangan** terdampak: 7 high, 4 moderate, seluruhnya di rantai firebase-tools. Paket: basic-ftp, braces, chokidar, firebase-tools, get-uri, pac-proxy-agent, proxy-agent, @google-cloud/pubsub, @opentelemetry/core, gaxios, uuid. Braces belum mempunyai rilis perbaikan dalam laporan ini. Saran otomatis mencakup perubahan mayor/downgrade CLI; tidak dijalankan tanpa validasi kompatibilitas. Override gRPC 1.14.5 dari v3.1.1 tetap dipertahankan. Ini **bukan** hasil audit bebas kerentanan. SDK browser melalui CDN tidak tercakup oleh npm audit.

Pencarian nama hanya pada status/ruang/entitas/periode aktif. Arsip/Sampah dimuat bertahap; gunakan Muat lebih lama untuk menelusuri hasil berikutnya. Riwayat lama yang sudah ditimpa sebelum trail tidak bisa dikembalikan. Akun, pengaturan Authentication, indeks aktif dan data produksi belum diperiksa; tidak dapat menyatakan seluruh sistem produksi bebas masalah. Data lama dengan tanggal kalender mustahil perlu dikoreksi admin agar perubahan dokumennya memenuhi aturan baru.

## Menjalankan pemeriksaan

```bash
npm ci
npm test
npm run test:rules
```

Suite rules memerlukan Java 21+, akses unduhan emulator, dan port lokal. Browser: jalankan `npm run preview`, lalu `python3 tests/browser-smoke.py --chromium /usr/bin/chromium` dengan Python Playwright/Chromium tersedia. Semua menggunakan demo/emulator dan tidak menulis produksi.

## Deploy

Upload ZIP ke Cloud Shell Home, ekstrak ke folder baru, lalu jalankan `bash deploy-cloud-shell.sh` di folder PostingDesk_RequestReverseAcc. Script memasang dependensi terkunci, menjalankan tes, login Firebase dan deploy rules/indeks/Hosting ke proyek eksplisit. Setelah Deploy complete, hard refresh browser/Teams dan periksa badge Selesai, nama/periode serta Hapus Cancel Park.
