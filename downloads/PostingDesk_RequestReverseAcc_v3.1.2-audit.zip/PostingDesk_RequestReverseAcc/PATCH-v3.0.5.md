# Patch v3.0.5 — Archive + Mobile + Compact View

- Menambahkan tombol **Arsip** langsung pada setiap dokumen berstatus Selesai untuk role `poster`.
- Tombol bulk diperjelas menjadi **Arsipkan dipilih** pada tab Selesai.
- Menambahkan pilihan tampilan **Lengkap / Ringkas** dan menyimpan preferensi secara lokal.
- Tampilan Ringkas mengurangi tinggi baris dan menyederhanakan metadata, terutama di mobile.
- Mobile dioptimalkan: kartu dokumen lebih rapih, tab status bisa digeser, selection actions tidak pecah berantakan, selection bar sticky saat ada pilihan, composer lebih pendek, dan kontrol daftar lebih mudah disentuh.
- Tidak mengubah Firestore Rules v3.0.3 yang sudah terbukti bekerja untuk delete requester/poster.
