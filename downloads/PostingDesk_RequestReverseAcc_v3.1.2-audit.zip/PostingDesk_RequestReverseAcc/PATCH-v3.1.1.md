# Posting Desk v3.1.1

Perbaikan untuk laporan tombol Hapus yang tidak muncul atau nonaktif di Cancel Park.

- Listener Firestore menerima perubahan metadata: daftar yang sudah ada di cache kini bisa menjadi siap ditulis setelah dikonfirmasi server, walaupun isi dokumennya sama.
- Dialog detail memperbarui tombol mengikuti koneksi, penyimpanan, dan data daftar terbaru.
- Filter tanggal tidak valid hanya memblokir Selesai/Arsip. Antrean/Sampah tetap dapat diproses. Memilih bulan valid, membuka hasil pencarian, mengirim, atau menyimpan edit membersihkan error tanggal lama.
- Hapus dipilih tetap terlihat sebelum memilih dokumen; petunjuk menjelaskan bahwa dokumen perlu dicentang. Requester tetap hanya dapat menghapus request open miliknya sendiri.
- Hasil pencarian dari sesi lama diabaikan setelah logout atau pergantian sesi.
- Preferensi lokal bernilai null tidak membuat aplikasi gagal dibuka.
- Field riwayat lama yang masih tersimpan tetap tampil setelah entri aktivitas baru dibuat.
- Timestamp berbentuk objek mempertahankan presisi nanodetik saat dikonversi ke milidetik.
- SDK pengujian memakai gRPC 1.14.5 melalui override terbatas; package-lock.json ditambahkan untuk instalasi berulang.

66 tes aplikasi dan 16 tes aturan Firestore Emulator lulus. Smoke test Chromium desktop dan mobile lulus untuk hapus/pulihkan tunggal dan massal di Cancel Park, termasuk setelah filter tanggal tidak valid. Pengujian rules mencakup AIO/ODI, pemosting/requester, data lama, serta konfirmasi cache setelah reconnect. Lihat AUDIT-v3.1.1.md.

## Memasang perbaikan

Ekstrak ke folder baru, lalu jalankan dari folder PostingDesk_RequestReverseAcc yang berisi firebase.json:

```sh
npm ci
npm test
npx firebase deploy --only hosting:requestreverseacc
```

Perubahan aplikasi ini belum dideploy ke Firebase produksi. Setelah deploy, muat ulang halaman dan pastikan label versi 3.1.1 terlihat. Pilih Cancel Park → AIO/ODI → centang request → Hapus dipilih, atau buka tombol … → Hapus. Periksa Sampah dan coba pulihkan satu request uji.

Firestore rules dan indexes sama dengan paket v3.1.0. Jika proyek produksi belum memakai rules/indexes v3.1.0, ikuti petunjuk upgrade di README dan validasi melalui emulator sebelum deploy Firestore. Penghapusan tetap memindahkan dokumen ke Sampah, bukan menghapus permanen.
