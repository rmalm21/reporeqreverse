# Posting Desk v3.1.2

- Badge Selesai tetap terlihat, dihitung sesuai ruang/entitas/pemilik/periode, tanpa Arsip/Sampah.
- Cari nama requester penuh/sebagian tanpa membedakan casing. Nama menyaring daftar aktif; lacak nomor global tetap tersedia.
- Filter bulan/tahun tanggal request bisa digabung dengan nama di semua status. Semua bulan + satu tahun juga tersedia. Tahun fiskal dokumen tetap terpisah.
- Reset membersihkan seluruh filter; hasil buat/edit tidak tersembunyi oleh filter sebelumnya.
- Batas kalender 2000–2099 dan validasi server terhadap tanggal mustahil/tahun kabisat.
- Seluruh perbaikan v3.1.1 termasuk Cancel Park dipertahankan.

## Deploy dari Cloud Shell

Upload ZIP ke folder Home. Ekstrak ke folder baru agar file versi lama tidak tercampur:

```bash
DEPLOY_DIR=$(mktemp -d "$HOME/postingdesk-3.1.2-XXXXXX")
unzip "$HOME/PostingDesk_RequestReverseAcc_v3.1.2-audit.zip" -d "$DEPLOY_DIR"
cd "$DEPLOY_DIR/PostingDesk_RequestReverseAcc"
bash deploy-cloud-shell.sh
```

Rules berubah, jadi script deploy rules/indeks dan Hosting. Target/proyek dikunci ke requestreverseacc / request-reverse-app. Tidak perlu firebase init. Ikuti login jika muncul, tunggu Deploy complete, lalu hard refresh web/Teams.

Lihat AUDIT-v3.1.2.md untuk hasil pemeriksaan dan temuan yang masih tersisa.
