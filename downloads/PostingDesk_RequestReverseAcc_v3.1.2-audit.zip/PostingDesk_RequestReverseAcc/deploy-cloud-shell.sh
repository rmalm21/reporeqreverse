#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
node --version
npm ci
npm test
npx firebase login --no-localhost
npx firebase deploy --project request-reverse-app --only firestore:rules,firestore:indexes,hosting:requestreverseacc
printf '\nDeploy selesai. Buka https://requestreverseacc.web.app dan hard refresh browser/Teams.\n'
