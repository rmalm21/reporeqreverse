// Konfigurasi Web App untuk project request-reverse-app.
export const APP_CONFIG = {
  name: 'Posting Desk',
  workspaceId: 'posting-team',
  firebaseConfig: {
    apiKey: 'AIzaSyBWoFx0cpGnW3eRTcqmO5Be3VsB6i75Gt0',
    authDomain: 'request-reverse-app.firebaseapp.com',
    projectId: 'request-reverse-app',
    storageBucket: 'request-reverse-app.firebasestorage.app',
    messagingSenderId: '931473727738',
    appId: '1:931473727738:web:a6b803e60265033254e943',
    measurementId: 'G-KNR51NLBXF'
  }
};
