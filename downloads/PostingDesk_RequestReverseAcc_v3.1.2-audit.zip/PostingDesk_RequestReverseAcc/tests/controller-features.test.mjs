import test from 'node:test';
import assert from 'node:assert/strict';
import { controllerFixture } from './helpers/controller-fixture.mjs';
import { createRecord, recordId, todayJakarta, transitionPatch } from '../public/domain.js';

const owner = { uid: 'test-user', displayName: 'Nisa Putri', role: 'poster' };
const make = (number, date, name = owner.displayName) => {
  const row = createRecord({ operation: 'cancel', entity: 'AIO', fiscalYear: '2025', requestDate: date, note: '' }, number, { ...owner, displayName: name }, 1000);
  return { ...row, id: recordId(row) };
};
const tick = () => new Promise(resolve => setImmediate(resolve));

test('completed badge stays visible from Antrean and counts only unarchived completed requests', async () => {
  const date = todayJakarta();
  const pending = make('5000000101', date);
  const done = { ...make('5000000102', date), ...transitionPatch(pending, 'done', owner, 2000) };
  const archived = { ...make('5000000103', date), ...transitionPatch(done, 'archive', owner, 3000) };
  const f = await controllerFixture({ initialRows: [pending, done, archived] });
  try {
    await tick();
    assert.equal(f.ids['done-count'].hidden, false);
    assert.equal(Number(f.ids['done-count'].textContent), 1);
    f.click('view', 'done');
    assert.equal(f.ids['done-count'].hidden, false);
    f.click('view', 'trash');
    assert.equal(f.ids['done-count'].hidden, false);
  } finally { f.cleanup(); }
});

test('name search ignores casing and whitespace and does not issue a global number lookup', async () => {
  let lookups = 0;
  const f = await controllerFixture({ initialRows: [make('5000000101', todayJakarta()), make('5000000102', todayJakarta(), 'Bing')], findDocuments: async () => { lookups++; return { rows: [], missing: [], truncated: false }; } });
  try {
    f.ids['search-number'].value = '  NISA   put '; f.ids['search-number'].handlers.input();
    assert.match(f.ids['list-summary'].textContent, /^1 dokumen/);
    assert.match(f.ids['request-rows'].innerHTML, /5000000101/);
    assert.doesNotMatch(f.ids['request-rows'].innerHTML, /5000000102/);
    f.ids['search-form'].handlers.submit({ preventDefault() {} }); await tick();
    assert.equal(lookups, 0);
    assert.match(f.ids['search-title'].textContent, /nama/i);
    assert.match(f.ids['search-summary'].textContent, /daftar aktif/);
    f.ids['search-dialog'].close();
    f.ids['search-number'].value = 'tidak ada'; f.ids['search-number'].handlers.input();
    assert.match(f.ids['list-summary'].textContent, /^0 dokumen/);
    f.ids['search-number'].value = ''; f.ids['search-number'].handlers.input();
    assert.match(f.ids['list-summary'].textContent, /^2 dokumen/);
  } finally { f.cleanup(); }
});

test('name/month/year filters combine in Antrean, use request date, and reset restores all rows', async () => {
  const f = await controllerFixture({ initialRows: [make('5000000101', '2026-10-01'), make('5000000102', '2026-09-01'), make('5000000103', '2025-10-01'), make('5000000104', '2026-10-02', 'Bing')] });
  try {
    f.ids['search-number'].value = 'nisa'; f.ids['search-number'].handlers.input();
    f.ids['filter-year'].value = '2026'; f.ids['filter-year'].handlers.change();
    f.ids['filter-month'].value = '10'; f.ids['filter-month'].handlers.change();
    assert.match(f.ids['list-summary'].textContent, /^1 dokumen/);
    assert.match(f.ids['request-rows'].innerHTML, /5000000101/);
    // A document's fiscal year is independent of the year of its request date.
    assert.match(f.ids['request-rows'].innerHTML, /2025/);
    f.ids['select-all'].checked = true; f.ids['select-all'].handlers.change({ target: f.ids['select-all'] });
    assert.equal(f.ids['bulk-delete'].disabled, false);
    f.ids['reset-filters'].handlers.click();
    assert.match(f.ids['list-summary'].textContent, /^4 dokumen/);
    assert.equal(f.ids['search-number'].value, '');
    assert.equal(f.ids['filter-month'].value, '');
    assert.equal(f.ids['filter-year'].value, '');
    assert.equal(f.ids['select-all'].checked, false);
  } finally { f.cleanup(); }
});

test('completed badge ignores an aggregation response from an obsolete entity scope', async () => {
  const calls = [];
  const f = await controllerFixture({ getDoneCount: scope => new Promise(resolve => calls.push({ scope, resolve })) });
  try {
    f.click('entity', 'ODI');
    assert.equal(calls.length, 2);
    calls[1].resolve(7); await tick();
    assert.equal(Number(f.ids['done-count'].textContent), 7);
    calls[0].resolve(99); await tick();
    assert.equal(Number(f.ids['done-count'].textContent), 7);
    f.signOut();
    assert.equal(f.ids['search-number'].value, '');
  } finally { f.cleanup(); }
});

test('month navigation remains within the supported 2000–2099 calendar', async () => {
  const f = await controllerFixture();
  try {
    f.ids['filter-year'].value = '2000'; f.ids['filter-year'].handlers.change();
    f.ids['filter-month'].value = '01'; f.ids['filter-month'].handlers.change();
    assert.equal(f.ids['month-prev'].disabled, true);
    f.ids['filter-year'].value = '2099'; f.ids['filter-year'].handlers.change();
    f.ids['filter-month'].value = '12'; f.ids['filter-month'].handlers.change();
    assert.equal(f.ids['month-next'].disabled, true);
    f.ids['reset-filters'].handlers.click();
    assert.equal(f.ids['bulk-delete'].hidden, false);
  } finally { f.cleanup(); }
});
