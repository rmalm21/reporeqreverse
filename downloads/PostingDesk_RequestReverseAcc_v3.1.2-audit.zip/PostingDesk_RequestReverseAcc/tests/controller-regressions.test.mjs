import test from 'node:test';
import assert from 'node:assert/strict';
import { controllerFixture } from './helpers/controller-fixture.mjs';

test('Cancel Park shows the delete control before selection and explains how to enable it', async () => {
  const f = await controllerFixture();
  try {
    assert.equal(f.ids['bulk-delete'].hidden, false);
    assert.equal(f.ids['bulk-delete'].disabled, true);
    assert.match(f.ids['bulk-delete'].title, /Centang dokumen/);
  } finally { f.cleanup(); }
});

test('requesters still cannot delete a colleague\'s Cancel Park request', async () => {
  const f = await controllerFixture({ role: 'requester' });
  try {
    const row = f.rows().find(row => row.operation === 'cancel' && row.entity === 'AIO');
    f.update(row.id, { createdByUid: 'another-user' });
    f.detail(row.id);
    assert.equal(f.ids['detail-delete'].hidden, true);
    f.ids['select-all'].checked = true; f.ids['select-all'].handlers.change({ target: f.ids['select-all'] });
    assert.equal(f.ids['bulk-delete'].disabled, true);
  } finally { f.cleanup(); }
});

for (const role of ['poster', 'requester']) {
  test(`Cancel Park ${role}: detail actions become enabled when cached data is confirmed by the server`, async () => {
    const f = await controllerFixture({ role, cached: true });
    try {
      f.detail();
      assert.equal(f.ids['detail-delete'].hidden, false);
      assert.equal(f.ids['detail-delete'].disabled, true);
      f.sync({ cached: false });
      assert.equal(f.ids['detail-delete'].disabled, false);
      f.ids['detail-delete'].handlers.click();
      await f.ids['confirm-action'].handlers.click();
      assert.equal(f.mutations.length, 1);
      assert.equal(f.mutations[0].scope.operation, 'cancel');
      assert.equal(f.rows().find(row => row.id === f.mutations[0].ids[0]).status, 'deleted');
      f.click('view', 'trash'); f.detail();
      f.ids['detail-action'].handlers.click(); await f.ids['confirm-action'].handlers.click();
      assert.equal(f.rows().find(row => row.id === f.mutations[0].ids[0]).status, 'pending');
    } finally { f.cleanup(); }
  });
}

test('an invalid date range in Selesai does not block Cancel Park Antrean or Sampah', async () => {
  const f = await controllerFixture();
  try {
    f.click('view', 'done');
    f.ids['date-preset'].value = 'custom';
    f.ids['date-from'].value = '2026-10-20'; f.ids['date-to'].value = '2026-10-01';
    f.ids['date-preset'].handlers.change();
    assert.equal(f.ids['filter-error'].hidden, false);
    f.click('room', 'reverse'); f.click('room', 'cancel');
    assert.equal(f.ids['period-filter'].hidden, true);
    f.ids['select-all'].checked = true; f.ids['select-all'].handlers.change({ target: f.ids['select-all'] });
    assert.equal(f.ids['bulk-delete'].disabled, false);
    f.ids['bulk-delete'].handlers.click(); await f.ids['confirm-action'].handlers.click();
    f.click('view', 'trash'); f.detail();
    assert.equal(f.ids['detail-action'].disabled, false);
    f.ids['detail-action'].handlers.click(); await f.ids['confirm-action'].handlers.click();
    f.click('view', 'done'); f.ids['month-current'].handlers.click();
    assert.equal(f.ids['filter-error'].hidden, true);
  } finally { f.cleanup(); }
});

test('detail buttons follow connection and row changes while the dialog is open', async () => {
  const f = await controllerFixture();
  try {
    f.detail();
    f.online(false); assert.equal(f.ids['detail-delete'].disabled, true);
    f.online(true); assert.equal(f.ids['detail-delete'].disabled, false);
    f.sync({ pendingWrites: true }); assert.equal(f.ids['detail-delete'].disabled, true);
    f.sync({ pendingWrites: false }); assert.equal(f.ids['detail-delete'].disabled, false);
    const row = f.rows().find(row => row.operation === 'cancel' && row.entity === 'AIO');
    f.update(row.id, { status: 'deleted', previousStatus: 'pending', updatedAt: 2000 });
    assert.equal(f.ids['detail-delete'].hidden, true);
    assert.equal(f.ids['detail-outside'].hidden, false);
  } finally { f.cleanup(); }
});

test('a search response from the previous account is discarded after sign-out', async () => {
  let finish;
  const f = await controllerFixture({ findDocuments: () => new Promise(resolve => { finish = resolve; }) });
  try {
    f.ids['search-number'].value = '5000000099'; f.ids['search-form'].handlers.submit({ preventDefault() {} });
    f.signOut();
    finish({ rows: [f.rows()[0]], missing: [], truncated: false });
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(f.ids['search-results'].innerHTML, '');
  } finally { f.cleanup(); }
});

test('null local preferences do not prevent the application from starting', async () => {
  const f = await controllerFixture({ preferences: 'null' });
  try { assert.equal(f.ids['page-title'].textContent, 'Cancel Park'); }
  finally { f.cleanup(); }
});
