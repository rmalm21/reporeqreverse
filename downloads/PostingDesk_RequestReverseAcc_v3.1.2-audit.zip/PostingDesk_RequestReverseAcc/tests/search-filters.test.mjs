import test from 'node:test';
import assert from 'node:assert/strict';
import { matchesName, parseListSearch, requestPeriod, matchesScope } from '../public/domain.js';

test('name search normalizes Unicode, whitespace and casing without confusing digits in names', () => {
  assert.deepEqual(parseListSearch('  ＮＩＳＡ   Putri 2 '), { name: 'nisa putri 2', terms: [] });
  assert.equal(matchesName({ requester: 'Nisa  Putri 2' }, ' NISA PUT '), true);
  assert.equal(matchesName({ requester: 'Bing' }, 'nisa'), false);
  assert.equal(matchesName({ requester: null }, 'nisa'), false);
  assert.deepEqual(parseListSearch('5000000101 5000000102'), { name: '', terms: ['5000000101', '5000000102'] });
});

test('month and year ranges include the last day and reject invalid periods', () => {
  assert.deepEqual(requestPeriod('2024', '02'), { from: '2024-02-01', to: '2024-02-29' });
  assert.deepEqual(requestPeriod('2026', '02'), { from: '2026-02-01', to: '2026-02-28' });
  assert.deepEqual(requestPeriod('2026'), { from: '2026-01-01', to: '2026-12-31' });
  assert.deepEqual(requestPeriod(''), { from: '', to: '' });
  assert.throws(() => requestPeriod('2100'), /tahun/);
  assert.throws(() => requestPeriod('2026', '13'), /bulan/);
});

test('an explicit period applies in pending/trash without changing their all-date defaults', () => {
  const row = { operation: 'cancel', entity: 'AIO', fiscalYear: '2025', requestDate: '2026-09-30', status: 'pending', archived: false };
  const scope = { operation: 'cancel', entity: 'AIO', view: 'pending', from: '2026-10-01', to: '2026-10-31' };
  assert.equal(matchesScope(row, scope), true);
  assert.equal(matchesScope(row, { ...scope, filterPeriod: true }), false);
  assert.equal(matchesScope({ ...row, requestDate: '2026-10-01' }, { ...scope, filterPeriod: true }), true);
  assert.equal(matchesScope({ ...row, status: 'deleted' }, { ...scope, view: 'trash', filterPeriod: true }), false);
});
